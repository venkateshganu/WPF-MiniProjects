﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;

namespace Asg3_vxg173330
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        //BROWSE BUTTON TO OPEN A FILE DIALOG AND SELECT A FILE TO OPEN (DATA ENTRY PROGRAM FILE)
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog db1 = new OpenFileDialog
            {
                
                Multiselect = false, //bLOCKING USER FROM SELECTING MULTIPLE FILES
                Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*", //FILTERING TO ALLOW SELECTING ONLY TEXT FILES
            };

            if (db1.ShowDialog() == DialogResult.OK) //IF DIALOG BOX IS OPENED AND LEGAL FILE IS SELECTED

            {
                textBox1.Text = db1.FileName; //FILL TEXT BOX WITH THE PATH OF THE FILE
                string str = db1.FileName; //STORE FILENAME IN A STRING TO BE USED LATER
            }
        }

        //BUTTON TO EVALUATE AND SIAPLY RESULTS IN THE DATA GRID VIEW

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add();
            dataGridView1.Rows.Add();
            dataGridView1.Rows.Add();
            dataGridView1.Rows.Add();
            dataGridView1.Rows.Add();
            dataGridView1.Rows.Add();
            dataGridView1.Rows.Add();
            dataGridView1.Rows.Add();
            int i = 0; //INITIALIZING i VALUE
            int backspace_counter = 0; //INITIALIZING BACKSPACE_COUNTER

            int record_count = 0; //INITIALIZING RECORD_COUNT
            string[] recordtime = new string[100]; //INITIALIZING RECORD TIME
            string[] interrecordtime = new string[100]; //INITIALIZING INTER RECORD TIME

            TimeSpan min_record_time = new TimeSpan(24, 24, 60, 60); //INITIALIZING MINIMUM RECORD TIME
            TimeSpan max_record_time = new TimeSpan(0, 0, 0, 0); //INITIALIZING MAXIMUM RECORD TIME
            TimeSpan total_record_time = new TimeSpan(0, 0, 0, 0); //INITIALIZING TOTAL RECORD TIME
            TimeSpan avg_record_time = new TimeSpan(0, 0, 0, 0); //INITIALIZING AVERAGE RECORD TIME

            TimeSpan min_inter_record_time = new TimeSpan(24, 24, 60, 60); //INITIALIZING MINIMUM INTER RECORD TIME
            TimeSpan max_inter_record_time = new TimeSpan(0, 0, 0, 0); //INITIALIZING MAXIMUM INTER RECORD TIME
            TimeSpan total_inter_record_time = new TimeSpan(0, 0, 0, 0); //INITIALIZING TOTAL INTER RECORD TIME
            TimeSpan avg_inter_record_time = new TimeSpan(0, 0, 0, 0); //INITIALIZING AVERAGE INTER RECORD TIME

            TimeSpan[] inter_record_time = new TimeSpan[100]; //DECLARING ARRAY TO STORE INTER_RECORD TIME RECORDS
            TimeSpan[] record_time = new TimeSpan[100]; //DECLARING ARRAY TO STORE RECORD TIME
            TimeSpan[] start_time = new TimeSpan[100]; //DECLARING ARRAY TO STORE START TIME
            TimeSpan[] end_time = new TimeSpan[100]; //DECLARING ARRAY TO STORE END TIME

            System.IO.StreamReader objReader;
           
            if (File.Exists(textBox1.Text)) //CHECK IF FILE EXITS
            {
                if (!string.IsNullOrEmpty(textBox1.Text)) //CHECK IF FILE PATH IS NOT NULL OR EMPTY
                {
                    objReader = new System.IO.StreamReader(textBox1.Text, true); //START READING FILE


                    while (!objReader.EndOfStream)
                    {

                        string line = objReader.ReadLine();
                        // MessageBox.Show(line.ToString());
                        string[] word = line.Split('\t').ToArray();

                        if (line != null)
                        {

                            record_time[i] = TimeSpan.Parse(line.Split('\t')[14]).Subtract(TimeSpan.Parse(line.Split('\t')[13]));
                            total_record_time = total_record_time + record_time[i];

                            start_time[i] = TimeSpan.Parse(line.Split('\t')[13]);
                            end_time[i] = TimeSpan.Parse(line.Split('\t')[14]);

                            if (record_time[i] < min_record_time)
                            {
                                min_record_time = record_time[i];
                            }

                            if (record_time[i] > max_record_time)
                            {
                                max_record_time = record_time[i];
                            }

                            i++;
                            record_count++;
                            backspace_counter = backspace_counter + int.Parse(line.Split('\t')[15]);
                        }
                    }
                    objReader.Close();

                    avg_record_time = TimeSpan.FromSeconds(total_record_time.TotalSeconds / record_count);

                    for (i = 1; i < record_count; i++)
                    {
                        inter_record_time[i] = start_time[i] - end_time[i - 1];

                        if (inter_record_time[i] < min_inter_record_time)
                        {
                            min_inter_record_time = inter_record_time[i];
                        }

                        if (inter_record_time[i] > max_inter_record_time)
                        {
                            max_inter_record_time = inter_record_time[i];
                        }

                        total_inter_record_time = total_inter_record_time + inter_record_time[i];
                    }

                    avg_inter_record_time = TimeSpan.FromSeconds(total_inter_record_time.TotalSeconds / record_count - 1);

                    //DISPLAY ALL THE ABOVE CALUCLATED RECORDS IN DATA GRID VIEW

                    dataGridView1.Rows[0].Cells[0].Value="Number of records: " + record_count; 
                    dataGridView1.Rows[1].Cells[0].Value="Minimum entry time: " + min_record_time.ToString(@"mm\:ss");
                    dataGridView1.Rows[2].Cells[0].Value="Maximum entry time: " + max_record_time.ToString(@"mm\:ss");
                    dataGridView1.Rows[3].Cells[0].Value="Average entry time: " + avg_record_time.ToString(@"mm\:ss");
                    dataGridView1.Rows[4].Cells[0].Value="Minimum inter-record time: " + min_inter_record_time.ToString(@"mm\:ss");
                    dataGridView1.Rows[5].Cells[0].Value="Maximum inter-record time: " + max_inter_record_time.ToString(@"mm\:ss");
                    dataGridView1.Rows[6].Cells[0].Value="Average inter-record time: " + avg_inter_record_time.ToString(@"mm\:ss");
                    dataGridView1.Rows[7].Cells[0].Value="Total time: " + total_record_time.ToString(@"mm\:ss");
                    dataGridView1.Rows[8].Cells[0].Value="Backspace count: " + backspace_counter;
                    //MessageBox.Show(dataGridView1.Rows[1].Cells[0].Value.ToString());
                }
            }
            else
            {
                MessageBox.Show("Enter valid text file path");
            }
            
        }

        //BUTTON TO CLEAR THE DATAGRID VIEW AND ALSO THE TEXT FILE PATH
        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //BUTTON TO SAVE THE RECORD DATA TO DEFAULT TEXT FILE LOCATION
        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("please enter text file path");
            }
            else
            {
                System.IO.StreamWriter objWriter;
                objWriter = new System.IO.StreamWriter("CS6326Asg3.txt", true);  //true will make program to add new lines and not to delete old lines.
                objWriter.WriteLine(dataGridView1.Rows[0].Cells[0].Value.ToString());
                objWriter.WriteLine(dataGridView1.Rows[1].Cells[0].Value.ToString());
                objWriter.WriteLine(dataGridView1.Rows[2].Cells[0].Value.ToString());
                objWriter.WriteLine(dataGridView1.Rows[3].Cells[0].Value.ToString());
                objWriter.WriteLine(dataGridView1.Rows[4].Cells[0].Value.ToString());
                objWriter.WriteLine(dataGridView1.Rows[5].Cells[0].Value.ToString());
                objWriter.WriteLine(dataGridView1.Rows[6].Cells[0].Value.ToString());
                objWriter.WriteLine(dataGridView1.Rows[7].Cells[0].Value.ToString());
                objWriter.WriteLine(dataGridView1.Rows[8].Cells[0].Value.ToString());
                objWriter.Close();
                dataGridView1.Rows.Clear();
                dataGridView1.Refresh();
                textBox1.Text = "";
            }

        }

        //BUTTON TO SAVE DATA TO A NEW FILE IN USER DESIRED LOCATION
        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("please enter text file path");
            }
            else
            { 
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.InitialDirectory = @"C:\";  
                saveFileDialog1.Title = "Save text File";
                //saveFileDialog1.CheckFileExists = true;
                saveFileDialog1.CheckPathExists = true;
                saveFileDialog1.DefaultExt = "txt";
                saveFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                saveFileDialog1.FilterIndex = 2;
                saveFileDialog1.RestoreDirectory = true;
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    System.IO.StreamWriter objWriter;
                    objWriter = new System.IO.StreamWriter(saveFileDialog1.FileName, true);  //true will make program to add new lines and not to delete old lines.
                    objWriter.WriteLine(dataGridView1.Rows[0].Cells[0].Value.ToString());
                    objWriter.WriteLine(dataGridView1.Rows[1].Cells[0].Value.ToString());
                    objWriter.WriteLine(dataGridView1.Rows[2].Cells[0].Value.ToString());
                    objWriter.WriteLine(dataGridView1.Rows[3].Cells[0].Value.ToString());
                    objWriter.WriteLine(dataGridView1.Rows[4].Cells[0].Value.ToString());
                    objWriter.WriteLine(dataGridView1.Rows[5].Cells[0].Value.ToString());
                    objWriter.WriteLine(dataGridView1.Rows[6].Cells[0].Value.ToString());
                    objWriter.WriteLine(dataGridView1.Rows[7].Cells[0].Value.ToString());
                    objWriter.WriteLine(dataGridView1.Rows[8].Cells[0].Value.ToString());
                    objWriter.Close();
                    dataGridView1.Rows.Clear();
                    dataGridView1.Refresh();
                    textBox1.Text = "";
                }
            }
        }
    }
}
