﻿/*Written by Venkatesh Gotimukul for CS6326.001, assignment 4, starting October 11, 2018.
NetID: vxg173330*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Threading;

namespace vxg173330Asg4
{
    /* initializing threads, golbal variables to start search again if needed*/
    public partial class Form1 : Form
    {
        int total_lines = 0;
        int line_count = 0;
        Queue q = Queue.Synchronized(new Queue());
        Thread t = Thread.CurrentThread;
        Thread thread1;
        Thread thread2;
        bool running = true;

        public Form1()
        {

            InitializeComponent();
            update();
        }

        /*Update function to create columns in Data grid view*/
        public void update()
        {
            dataGridView1.ColumnCount = 2;
            dataGridView1.Columns[0].Name = "Line Number";
            dataGridView1.Columns[1].Name = "Line Containing Keyword";
        }

        /*Form load event to handle all the button disable events and hiding progress bar
        Making sovereign app screen responsive.*/
        private void Form1_Load(object sender, EventArgs e)
        {
            progressBar1.Hide();
            button3.Visible = false;
            button4.Enabled = false;
            this.AutoSize = true;
            int h = Screen.PrimaryScreen.WorkingArea.Height - this.Height;
            this.Height += h;
            int w = Screen.PrimaryScreen.WorkingArea.Width - this.Width;
            this.Width += w;
            this.CenterToScreen();
            if (textBox2.Text == "")
            {
                button2.Enabled = false;
            }
        }

        /*Read Thread function to read all the lines of text file and store them in a queue*/
        public void ReadThreadFunction()
        {
            running = true;
            Console.Write("Entered ReadThread");
            line_count = 0;
            System.IO.StreamReader objReader;
            Control.CheckForIllegalCrossThreadCalls = false;
            try
            {

                if (File.Exists(textBox1.Text)) //CHECK IF FILE EXITS
                {
                    if (!string.IsNullOrEmpty(textBox1.Text)) //CHECK IF FILE PATH IS NOT NULL OR EMPTY
                    {
                        objReader = new System.IO.StreamReader(textBox1.Text, true); //START READING FILE

                        while (!objReader.EndOfStream)
                        {

                            string line = objReader.ReadLine();
                            // MessageBox.Show(line.ToString());
                            string[] word = line.Split(' ').ToArray();

                            if (line != null)
                            {
                                line_count = line_count + 1;
                                progressbarfunc(line_count);
                                for (int i = 0; i < word.Length; i++)
                                {
                                    if (word[i].ToLower().Contains(textBox2.Text.ToLower()))
                                    {
                                        string[] row = new string[] { line_count.ToString(), line };
                                        string row2 = line_count.ToString() + '\t' + line;
                                        q.Enqueue(row2);
                                        Thread.Sleep(1);
                                    }
                                }
                            }

                        }
                        running = false;
                        button4.Enabled = true;
                        button3.Hide();
                        button2.Show();
                        //thread1.Abort();
                        //thread2.Abort();
                        objReader.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Enter valid text file path");
                    //button2.Enabled = false;
                }
            }
            catch (ThreadInterruptedException e1)
            {
                Console.Write("Main thread interrupted" + e1);
            }
        }

        /*Progress bar function to indicate the progress corresponding to lines of text file*/
        public int progressbarfunc(int line_count)
        {
            progressBar1.Value = line_count * 100 / total_lines;
            return progressBar1.Value;
        }

        /*Browse button to open text files in dialog box*/
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog db1 = new OpenFileDialog();
            db1.Title = "Open text file";
            db1.Multiselect = false; //bLOCKING USER FROM SELECTING MULTIPLE FILES
            db1.Filter = "TXT files|*.txt"; //FILTERING TO ALLOW SELECTING ONLY TEXT FILES

            if (db1.ShowDialog() == DialogResult.OK) //IF DIALOG BOX IS OPENED AND LEGAL FILE IS SELECTED
            {
                textBox1.Text = db1.FileName; //FILL TEXT BOX WITH THE PATH OF THE FILE
                string str = db1.FileName; //STORE FILENAME IN A STRING TO BE USED LATER
            }
            total_lines = File.ReadLines(textBox1.Text).Count();
            //MessageBox.Show(total_lines.ToString());
        }

        /*Button to start the threads and start the search task and enabling other options
         like buttons, progress bar*/
        public void button2_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Visible = false;
            button3.Visible = true;
            button4.Enabled = false;
            //button4.Enabled = true;
            progressBar1.Show();
            progressBar1.Value = 0;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            thread1 = new Thread(new ThreadStart(WriteThreadFunction));
            thread2 = new Thread(new ThreadStart(ReadThreadFunction));
            thread2.Start();
            thread1.Start();

        }

        /*Write thread function in second thread which dequeques the line and number 
        from the queue and displays in the data grid view*/
        private void WriteThreadFunction()
        {
            try
            {
                while (running)
                {
                    if (q.Count > 0)
                    {
                        string[] row3 = q.Dequeue().ToString().Split('\t');
                        dataGridView1.Rows.Add(row3);
                        Thread.Sleep(100);
                    }
                    Thread.Sleep(100);
                }
            }

            catch (Exception e7)
            {
                Console.WriteLine("write thread exception" + e7);
            }
        }

        /*Button to cancel the search operation and abort the threads*/
        private void button3_Click(object sender, EventArgs e)
        {
            button3.Hide();
            button2.Show();
            thread1.Abort();
            thread2.Abort();
            button4.Enabled = true;
            button1.Enabled = true;
        }

        /* Button to clear all the text boxes and hide progress bar*/
        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            button2.Visible = true;
            button3.Visible = false;
            button4.Enabled = false;
            progressBar1.Hide();
        }

        /* Datagrif view cell content function to prevent clicking errors and avoiding stack trace*/
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        /*Text box changed event for search keywork which enables search button 
         * only when there is a word in the textbox*/
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                button2.Enabled = true;
            }
            else
            {
                button2.Enabled = false;
            }
        }

        /* Timer tick to support progress bar in case of line error in text file */
        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar1.Increment(1);
        }

        /*If user manipulates valid file path and enters invalid path*/
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (File.Exists(textBox1.Text))
            {
                button2.Enabled = true;
            }
            else {
                MessageBox.Show("No file found please enter valid file again");
                button2.Enabled = false;
            }
        }
    }
}
