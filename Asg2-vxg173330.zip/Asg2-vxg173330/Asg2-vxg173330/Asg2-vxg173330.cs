﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Globalization;

namespace Asg2_vxg173330
{
    public partial class Asg2_vxg173330 : Form
    {
        public int rowindex; //ROW INDEX PARAMETER FOR DATAGRID VIEW ROW
        public string line1; //GLOBAL DECLARATION FOR STRING VARIABLE line1
        public string line2; //GLOBAL DECLARATION FOR STRING VARIABLE line2
        public string line3; //GLOBAL DECLARATION FOR STRING VARIABLE line3
        public int backspace_counter = 0; //DECLARING AND INTIALIZING BACKSPACE COUNTER TO 0
        public TimeSpan start_time; //DECLARING START_TIME WHICH HAS TIME WHEN FIRST CHARACTER IS ENTERED IN FIRST TEXTBOX
        public TimeSpan save_time; //DECLARING SAVE_TIME WHICH HAS TIME WHEN CLERK TYPED SAVE BUTTON

        public Asg2_vxg173330()
        {
            InitializeComponent();
        }
        int rowcount;

        //DEFAULTING THE DATE FOR THE FORM WHEN THE FORM LOADS TO TODAY'S DATE

        private void Asg2_vxg173330_Load(object sender, EventArgs e)
        {
            textBox11.Text = DateTime.Today.ToString("dd/MM/yyyy");
            System.IO.StreamReader objReader;

        //DISPLAYING THE FULL NAME AND PHONE NUMBER ON DATA GRID VIEW WHEN THE FORM IS OPENED/LOADED.
            string[] fullName = new string[100];
            string[] phoneNumber = new string[100];
            objReader = new System.IO.StreamReader("CS6326Asg2.txt");
            int i = 0;
            while (!objReader.EndOfStream)
            {

                string line = objReader.ReadLine();

                string[] word = line.Split('\t').ToArray();
                fullName[i] = word[0] + " " + word[1] + " " + word[2];
                phoneNumber[i] = word[9];

                i++;
            }
            for (int j = 0; j < fullName.Length; j++)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[j].Cells[0].Value = fullName[j];
                dataGridView1.Rows[j].Cells[1].Value = phoneNumber[j];
            }
            rowcount = fullName.Length - 1;
            objReader.Close();

            
        }

        //BACKSPACE COUNTER FUNCTION

        private void bs_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                backspace_counter++;
            }
        }

        //FUNCTION TO READ THE CONTENTS OF FILE AND GET AN ARRAY OF FULL NAME AND PHONE NUMBER TO CHECK DUPLICATES
        protected string[] readName()
        {
            System.IO.StreamReader objReader;
            string[] fullName = new string[100];
            string[] phoneNumber = new string[100];
            objReader = new System.IO.StreamReader("CS6326Asg2.txt");
            int i = 0;
            while (!objReader.EndOfStream)
            {

                string line = objReader.ReadLine();
               // MessageBox.Show(line.ToString());
                string[] word = line.Split('\t').ToArray();
               
                if (word.Length != 0)
                {
                    fullName[i] = word[0] + word[2]+word[9];
                    i++;
                }
            }
            
            objReader.Close();
            return fullName;
        }
        //TIME SAVED WHEN USER ENTERED FIRST CHARACTER AND CHANGED THE CONTENT IN TEXTBOX1
            private void textBox1_TextChanged(object sender, EventArgs e)
        {
            start_time = DateTime.Now.TimeOfDay;
        }
        
        //DATAGRID VIEW FUNCION TO SHOW CONTENTS IN TEXTBOX WHEN A ROW WITH RECORDS IS SELECTED
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            rowindex = dataGridView1.CurrentRow.Index;
            line1 = System.IO.File.ReadLines("CS6326Asg2.txt").Skip(rowindex).Take(1).First();
            string[] word1 = line1.Split('\t').ToArray();
            textBox1.Text = word1[0];
            textBox2.Text = word1[1];
            textBox3.Text = word1[2];
            textBox4.Text = word1[3];
            textBox5.Text = word1[4];
            textBox6.Text = word1[5];
            textBox7.Text = word1[6];
            textBox8.Text = word1[7];
            comboBox1.Text = word1[8];
            textBox9.Text = word1[9];
            textBox10.Text = word1[10];
            comboBox2.Text = word1[11];
            textBox11.Text = word1[12];
            buttonClick1.Enabled = true;
        }

        //ADD OR SAVE BUTTON TO VALIDATE THE MANDATORY FILEDS, VALIDATE FORMATS LIKE FOR DATE, CHECK FOR DUPLICATE RECORDS ADDITION, WRITING CONTENTS TO THE FILE ALONG WITH THREE INVISIBLE FIELDS. 
        private void buttonClick1_Click(object sender, EventArgs e)
        {
            if ((string.IsNullOrEmpty(textBox1.Text)) || (string.IsNullOrEmpty(textBox3.Text)) || (string.IsNullOrEmpty(textBox4.Text)) || (string.IsNullOrEmpty(textBox6.Text)) || (string.IsNullOrEmpty(textBox7.Text)) || (string.IsNullOrEmpty(textBox8.Text)) || (string.IsNullOrEmpty(textBox9.Text)) || (string.IsNullOrEmpty(textBox10.Text)) || (string.IsNullOrEmpty(textBox11.Text)) || (string.IsNullOrEmpty(comboBox1.Text)) || (string.IsNullOrEmpty(comboBox2.Text)))
            {
                MessageBox.Show("Please fill all mandatory fields");
            }
            
            else
            
            {
                Regex regex = new Regex(@"(((0|1)[0-9]|2[0-9]|3[0-9])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$");
                bool isValid = regex.IsMatch(textBox11.Text.Trim());
                DateTime dt;
                isValid = DateTime.TryParseExact(textBox11.Text, "dd/MM/yyyy", new CultureInfo("en-GB"), DateTimeStyles.None, out dt);
                if (!isValid)
                {
                    MessageBox.Show("Invalid date format");
                }
                else { 
                string[] lname = new string[100];
                string[] arrName = readName();
                if (arrName.Length != 0)
                {
                    string name3 = textBox1.Text + textBox3.Text + textBox9.Text;

                        if (arrName.Contains(name3))
                        {
                            MessageBox.Show("Duplicate Record Error");
                        }

                        else
                        {
                            int n = dataGridView1.Rows.Add();
                            dataGridView1.Rows[n].Cells[0].Value = textBox1.Text + " " + textBox2.Text + " " + textBox3.Text;
                            dataGridView1.Rows[n].Cells[1].Value = textBox9.Text;
                            System.IO.StreamWriter objWriter;
                            objWriter = new System.IO.StreamWriter("CS6326Asg2.txt", true);  //true will make program to add new lines and not to delete old lines.
                            objWriter.Write(textBox1.Text + '\t');
                            objWriter.Write(textBox2.Text + '\t');
                            objWriter.Write(textBox3.Text + '\t');
                            objWriter.Write(textBox4.Text + '\t');
                            objWriter.Write(textBox5.Text + '\t');
                            objWriter.Write(textBox6.Text + '\t');
                            objWriter.Write(textBox7.Text + '\t');
                            objWriter.Write(textBox8.Text + '\t');
                            objWriter.Write(comboBox1.Text + '\t');
                            objWriter.Write(textBox9.Text + '\t');
                            objWriter.Write(textBox10.Text + '\t');
                            objWriter.Write(comboBox2.Text + '\t');
                            textBox11.Text = DateTime.Today.ToString("dd/MM/yyyy");
                            objWriter.Write(textBox11.Text + '\t');
                            save_time = DateTime.Now.TimeOfDay;
                            objWriter.Write(start_time.ToString() + '\t');
                            objWriter.Write(save_time.ToString() + '\t');
                            objWriter.WriteLine(backspace_counter);
                            objWriter.Close();
                            textBox1.Text = "";
                            textBox2.Text = "";
                            textBox3.Text = "";
                            textBox4.Text = "";
                            textBox5.Text = "";
                            textBox6.Text = "";
                            textBox7.Text = "";
                            textBox8.Text = "";
                            comboBox1.Text = "";
                            textBox9.Text = "";
                            textBox10.Text = "";
                            comboBox2.Text = "";
                            textBox11.Text = DateTime.Today.ToString("dd/MM/yyyy");
                        } 
                    }
                }
               
            }
            Asg2_vxg173330_Load(sender,e);
        }
        
        //MODIFY BUTTON TO MODIFY THE RECORD AND REWRITE THE VALUE IN THE FILE REMOVING THE PREVIOUS RECORD AND VALIDATING THE DUPLIACTE PROPERTY ALONG WITH MANDATORY FILEDS PROPERTY.
        private void buttonClick2_Click(object sender, EventArgs e)
        {

            rowindex = dataGridView1.CurrentRow.Index;
            line3= System.IO.File.ReadLines("CS6326Asg2.txt").Skip(rowindex).Take(1).First();
            string[] word3= line3.Split('\t').ToArray();
            System.IO.File.WriteAllLines("CS6326Asg2.txt", System.IO.File.ReadLines("CS6326Asg2.txt").Where(l => l != line3).ToList());
            int n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = textBox1.Text + " " + textBox2.Text + " " + textBox3.Text;
            dataGridView1.Rows[n].Cells[1].Value = textBox9.Text;
            System.IO.StreamWriter objWriter;
            objWriter = new System.IO.StreamWriter("CS6326Asg2.txt", true);  //true will make program to add new lines and not to delete old lines.
            objWriter.Write(textBox1.Text + "\t");
            objWriter.Write(textBox2.Text + "\t");
            objWriter.Write(textBox3.Text + "\t");
            objWriter.Write(textBox4.Text + "\t");
            objWriter.Write(textBox5.Text + "\t");
            objWriter.Write(textBox6.Text + "\t");
            objWriter.Write(textBox7.Text + "\t");
            objWriter.Write(textBox8.Text + "\t");
            objWriter.Write(comboBox1.Text + "\t");
            objWriter.Write(textBox9.Text + "\t");
            objWriter.Write(textBox10.Text + "\t");
            objWriter.Write(comboBox2.Text + "\t");
            objWriter.WriteLine(textBox11.Text);
            objWriter.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            comboBox1.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            comboBox2.Text = "";
            textBox11.Text = DateTime.Today.ToString("dd/MM/yyyy");
            Asg2_vxg173330_Load(sender, e);
            buttonClick1.Enabled = true;
        }

        //DELETE BUTTON TO REMOVE THE RECORD FROM THE DATGRID VIEW AS WELL AS FROM TEXTBOX MOVING OTHER RECORDS UP.
        private void buttonClick3_Click(object sender, EventArgs e)
        {
            rowindex = dataGridView1.CurrentRow.Index;
            line2 = System.IO.File.ReadLines("CS6326Asg2.txt").Skip(rowindex).Take(1).First();
            string[] word1 = line2.Split('\t').ToArray();
            System.IO.File.WriteAllLines("CS6326Asg2.txt", System.IO.File.ReadLines("CS6326Asg2.txt").Where(l =>l!= line2).ToList());
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            comboBox1.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            comboBox2.Text = "";
            textBox11.Text = DateTime.Today.ToString("dd/MM/yyyy");
            Asg2_vxg173330_Load(sender, e);
        }

        //CANCEL BUTTON TO REMOVE ALL THE RECORDS ENTERED INTO FORM OR REMOVE THE RECORDS WHEN MODIFY BUTTON IS SELECTED BUT USER DOESN'T WANT TO MODIFY.
        private void buttonClick4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            comboBox1.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            comboBox2.Text = "";
            textBox11.Text = DateTime.Today.ToString("dd/MM/yyyy");
        }

        //FUNCTION TO ENTER ONLY NUMBERS FOR ZIPCODE, TO USE BACKSPACE AND DELETE KEY
        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if(!Char.IsDigit(ch)&& ch!=8 &&ch!=46)
            {
                e.Handled = true;
            }
        }

        //FUNCTION TO ENTER ONLY NUMBERS FOR PHONE NUMBER, TO USE BACKSPACE AND DELETE KEY
        private void textBox9_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        //FUNCTION TO VALIDATE DUPLICATE RECORD KEYS WHEN USER WITH SAME FULL NAME AND PHONE NUMBER IS ENTERED.
        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            string[] lname = new string[100];
            string[] arrName = readName();
            if (arrName.Length != 0)
            {
                string name3 = textBox1.Text + textBox3.Text + textBox9.Text;

                if (arrName.Contains(name3))
                {
                    buttonClick1.Enabled = false;
                }
            }
        }
    }
}
